# cat_dog_data —— 範例資料集

每個類別一個資料夾（`cats/`、`dogs/`，各 500 張、最長邊 224px）。
把 `cat_dog_data/` 換成你自己的圖片時，維持同樣的版面即可。

來源：Microsoft Research「Kaggle Cats and Dogs Dataset」
（https://www.microsoft.com/en-us/download/details.aspx?id=54765 ，
  教學研究用途）。製作：取每類編號最小的 500 張可完整解碼的圖，
  縮至 224px、JPEG q85。腳本見 repo 的 scripts/curate 記錄（commit 訊息）。
